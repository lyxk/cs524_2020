#!/bin/bash

sbatch task1.sh

sbatch task2-1.sh
sbatch task2-2.sh
sbatch task2-3.sh

sbatch task3-1.sh 
sbatch task3-2.sh 
sbatch task3-3.sh

sbatch task4.sh