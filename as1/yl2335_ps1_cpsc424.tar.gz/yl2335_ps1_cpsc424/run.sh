echo -e "\n---------------Make------------------"

make clean
make -j

echo -e "\n------------Ex1 Option a-------------"

./ex1a

echo -e "\n------------Ex1 Option b-------------"

./ex1b

echo -e "\n------------Ex1 Option c-------------"

./ex1c

echo -e "\n----------------Ex2------------------"

./ex2
