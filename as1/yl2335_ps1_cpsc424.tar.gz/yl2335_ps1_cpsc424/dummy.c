#include "dummy.h"

void dummy() { 
    return; 
}
