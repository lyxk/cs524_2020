sbatch task1.sh

sbatch task2a.sh
sbatch task2b41.sh
sbatch task2b42.sh
sbatch task2b44.sh
sbatch task2b81.sh
sbatch task2b82.sh
sbatch task2b84.sh

sbatch task3a.sh
sbatch task3b41.sh
sbatch task3b42.sh
sbatch task3b44.sh
sbatch task3b81.sh
sbatch task3b82.sh
sbatch task3b84.sh

sbatch task4a.sh
sbatch task4b41.sh
sbatch task4b42.sh
sbatch task4b44.sh
sbatch task4b81.sh
sbatch task4b82.sh
sbatch task4b84.sh

sbatch task5.sh
